# Spring Boot Sample Project

회원관리 시스템을 위한 스프링부트 샘플 프로젝트입니다.

## 기술 스택

- **Spring Boot 3.2.0**
- **MyBatis 3.0.3**
- **H2 Database** (인메모리)
- **Java 17**
- **Maven**

## 프로젝트 구조

### 📁 전체 디렉토리 구조
```
sample_project/
├── src/
│   ├── main/
│   │   ├── java/sg/sample/
│   │   │   ├── controller/
│   │   │   │   ├── UserController.java      # 회원 관리 API
│   │   │   │   └── AuthController.java      # 인증 관리 API
│   │   │   ├── service/
│   │   │   │   ├── UserService.java         # 회원 비즈니스 로직
│   │   │   │   └── AuthService.java         # 인증 비즈니스 로직
│   │   │   ├── dao/
│   │   │   │   ├── UserDAO.java             # 회원 데이터 접근
│   │   │   │   ├── UserProfileDAO.java      # 프로필 데이터 접근
│   │   │   │   └── UserRoleDAO.java         # 권한 데이터 접근
│   │   │   ├── mapper/
│   │   │   │   ├── UserMapper.java          # MyBatis 매퍼 인터페이스
│   │   │   │   ├── UserProfileMapper.java
│   │   │   │   └── UserRoleMapper.java
│   │   │   ├── model/
│   │   │   │   ├── User.java                # 회원 엔티티
│   │   │   │   ├── UserProfile.java         # 프로필 엔티티
│   │   │   │   └── UserRole.java            # 권한 엔티티
│   │   │   ├── co/
│   │   │   │   ├── constants/
│   │   │   │   │   ├── Constants.java       # 상수 정의
│   │   │   │   │   └── UserRoleEnum.java    # 권한 열거형
│   │   │   │   └── utils/
│   │   │   │       ├── PasswordUtils.java   # 비밀번호 유틸리티
│   │   │   │       └── ValidationUtils.java # 검증 유틸리티
│   │   │   └── SampleApplication.java       # 메인 애플리케이션
│   │   └── resources/
│   │       ├── application.properties       # 애플리케이션 설정
│   │       ├── schema.sql                   # 데이터베이스 스키마
│   │       └── mapper/
│   │           ├── UserMapper.xml           # MyBatis XML 매퍼
│   │           ├── UserProfileMapper.xml
│   │           └── UserRoleMapper.xml
│   └── test/                                # 테스트 코드 (선택사항)
├── target/                                  # 빌드 결과물 (gitignore)
├── pom.xml                                  # Maven 설정
├── README.md                                # 프로젝트 문서
├── calltree.md                              # API 콜트리 문서
└── .gitignore                               # Git 제외 파일
```

### 🏗️ 아키텍처 구조
```
┌─────────────────┐
│   Controller    │  ← REST API 엔드포인트
├─────────────────┤
│    Service      │  ← 비즈니스 로직
├─────────────────┤
│      DAO        │  ← 데이터 접근 계층
├─────────────────┤
│     Mapper      │  ← MyBatis 매퍼
├─────────────────┤
│   Database      │  ← H2 인메모리 DB
└─────────────────┘
```

## 실행 방법

### 1. 프로젝트 빌드 및 컴파일
```bash
# 프로젝트 클린 빌드 및 컴파일
mvn clean compile
```

**빌드 결과 예시:**
```
[INFO] Scanning for projects...
[INFO] Building sample-project 1.0.0
[INFO] 
[INFO] --- clean:3.3.2:clean (default-clean) @ sample-project ---
[INFO] 
[INFO] --- resources:3.3.1:resources (default-resources) @ sample-project ---
[INFO] Copying 1 resource from src/main/resources to target/classes
[INFO] Copying 4 resources from src/main/resources to target/classes
[INFO] 
[INFO] --- compiler:3.11.0:compile (default-compile) @ sample-project ---
[INFO] Compiling 18 source files with javac [debug release 17] to target/classes
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
```

### 2. 애플리케이션 실행

#### 포그라운드 실행 (로그 실시간 확인)
```bash
mvn spring-boot:run
```

**서버 시작 로그 예시:**
```
  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::                (v3.2.0)

2025-08-16T17:45:45.344+09:00  INFO 4291 --- [           main] sg.sample.SampleApplication              : Starting SampleApplication using Java 21.0.1 with PID 4291
2025-08-16T17:45:45.651+09:00 DEBUG 4291 --- [           main] o.m.s.mapper.ClassPathMapperScanner      : Identified candidate component class: file [/Users/soogom/devAI/java_workspace/sample_project/target/classes/sg/sample/mapper/UserMapper.class]
2025-08-16T17:45:45.840+09:00  INFO 4291 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat initialized with port 8080 (http)
2025-08-16T17:45:45.977+09:00  INFO 4291 --- [           main] com.zaxxer.hikari.pool.HikariPool        : HikariPool-1 - Added connection conn0: url=jdbc:h2:mem:testdb user=SA
2025-08-16T17:45:45.983+09:00  INFO 4291 --- [           main] o.s.b.a.h2.H2ConsoleAutoConfiguration    : H2 console available at '/h2-console'. Database available at 'jdbc:h2:mem:testdb'
2025-08-16T17:45:46.357+09:00  INFO 4291 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port 8080 (http) with context path ''
2025-08-16T17:45:46.361+09:00  INFO 4291 --- [           main] sg.sample.SampleApplication              : Started SampleApplication in 1.186 seconds (process running for 1.335)
```

#### 백그라운드 실행
```bash
mvn spring-boot:run &
```

### 3. 서버 종료

#### 포그라운드 실행 중인 경우
```bash
# Ctrl + C (터미널에서)
```

#### 백그라운드 실행 중인 경우
```bash
# 프로세스 ID 확인
ps aux | grep java

# 프로세스 종료
pkill -f "SampleApplication"
```

**서버 종료 로그 예시:**
```
^C2025-08-16T17:46:22.498+09:00  INFO 4291 --- [ionShutdownHook] com.zaxxer.hikari.HikariDataSource       : HikariPool-1 - Shutdown initiated...
2025-08-16T17:46:22.500+09:00  INFO 4291 --- [ionShutdownHook] com.zaxxer.hikari.HikariDataSource       : HikariPool-1 - Shutdown completed.
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time:  38.269 s
[INFO] Finished at: 2025-08-16T17:46:22+09:00
[INFO] ------------------------------------------------------------------------
```

### 4. 접속 정보
- **애플리케이션**: http://localhost:8080
- **H2 콘솔**: http://localhost:8080/h2-console
  - JDBC URL: `jdbc:h2:mem:testdb`
  - Username: `sa`
  - Password: (비어있음)

### 5. API 테스트 (curl)

#### 기본 테스트
```bash
# 서버 상태 확인
curl http://localhost:8080/api/users

# 응답 예시:
# {"data":[{"id":1,"username":"admin","email":"admin@example.com",...}],"success":true,"count":3,"message":"Users retrieved successfully"}
```

#### 회원 관리 API 테스트
```bash
# 1. 전체 회원 조회
curl http://localhost:8080/api/users

# 2. 특정 회원 조회
curl http://localhost:8080/api/users/1

# 3. 새 회원 등록
curl -X POST http://localhost:8080/api/users \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "password123"
  }'

# 4. 회원 정보 수정
curl -X PUT http://localhost:8080/api/users/1 \
  -H "Content-Type: application/json" \
  -d '{
    "email": "updated@example.com"
  }'

# 5. 회원 삭제
curl -X DELETE http://localhost:8080/api/users/4

# 6. 회원 상태 변경
curl -X PUT http://localhost:8080/api/users/1/status \
  -H "Content-Type: application/json" \
  -d '{"status": "INACTIVE"}'
```

#### 프로필 관리 API 테스트
```bash
# 1. 프로필 생성
curl -X POST http://localhost:8080/api/users/1/profile \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "John",
    "lastName": "Doe",
    "phoneNumber": "010-1234-5678",
    "address": "Seoul, South Korea",
    "birthDate": "1990-01-01",
    "gender": "M"
  }'

# 2. 프로필 조회
curl http://localhost:8080/api/users/1/profile

# 3. 프로필 수정
curl -X PUT http://localhost:8080/api/users/1/profile \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Updated",
    "lastName": "Name"
  }'
```

#### 인증 관리 API 테스트
```bash
# 1. 로그인
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "password123"
  }'

# 2. 사용자 프로필 조회
curl http://localhost:8080/api/auth/profile/1

# 3. 권한 확인
curl "http://localhost:8080/api/auth/check-role/1?roleCode=ADMIN"

# 4. 관리자 권한 확인
curl http://localhost:8080/api/auth/check-admin/1

# 5. 사용자 접근 검증
curl -X POST http://localhost:8080/api/auth/validate-access/1
```

#### 응답 형식 예시
```bash
# 성공 응답
{
  "success": true,
  "message": "Users retrieved successfully",
  "data": [...],
  "count": 3
}

# 오류 응답
{
  "success": false,
  "message": "User not found with id: 999"
}
```

## API 엔드포인트

### 회원 관리 API (`/api/users`)

#### 1. 회원 등록
```http
POST /api/users
Content-Type: application/json

{
  "username": "newuser",
  "email": "newuser@example.com",
  "password": "password123"
}
```

#### 2. 회원 조회
```http
GET /api/users/{id}
```

#### 3. 전체 회원 조회
```http
GET /api/users
```

#### 4. 회원 정보 수정
```http
PUT /api/users/{id}
Content-Type: application/json

{
  "username": "updateduser",
  "email": "updated@example.com"
}
```

#### 5. 회원 삭제
```http
DELETE /api/users/{id}
```

#### 6. 회원 상태 변경
```http
PUT /api/users/{id}/status
Content-Type: application/json

{
  "status": "INACTIVE"
}
```

#### 7. 프로필 생성
```http
POST /api/users/{id}/profile
Content-Type: application/json

{
  "firstName": "John",
  "lastName": "Doe",
  "phoneNumber": "010-1234-5678",
  "address": "Seoul, South Korea",
  "birthDate": "1990-01-01",
  "gender": "M"
}
```

#### 8. 프로필 조회
```http
GET /api/users/{id}/profile
```

#### 9. 프로필 수정
```http
PUT /api/users/{id}/profile
Content-Type: application/json

{
  "firstName": "Updated",
  "lastName": "Name"
}
```

### 인증 관리 API (`/api/auth`)

#### 1. 로그인
```http
POST /api/auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "password123"
}
```

#### 2. 프로필 조회
```http
GET /api/auth/profile/{userId}
```

#### 3. 권한 확인
```http
GET /api/auth/check-role/{userId}?roleCode=ADMIN
```

#### 4. 관리자 권한 확인
```http
GET /api/auth/check-admin/{userId}
```

#### 5. 사용자 접근 검증
```http
POST /api/auth/validate-access/{userId}
```

## 샘플 데이터

애플리케이션 시작 시 다음 샘플 데이터가 자동으로 생성됩니다:

### 사용자
- **admin** (admin@example.com) - 관리자 권한
- **user1** (user1@example.com) - 일반 사용자
- **user2** (user2@example.com) - 일반 사용자

### 비밀번호
모든 사용자의 비밀번호는 `password123`입니다.

## 주요 기능

### 🎯 핵심 기능

#### 1. 회원 관리 시스템
- **회원 CRUD**: 등록, 조회, 수정, 삭제
- **중복 검증**: 이메일/사용자명 중복 확인
- **비밀번호 보안**: SHA-256 해싱
- **상태 관리**: ACTIVE, INACTIVE, DELETED 상태 관리

#### 2. 프로필 관리 시스템
- **상세 정보**: 이름, 전화번호, 주소, 생년월일, 성별
- **프로필 CRUD**: 프로필 생성, 조회, 수정
- **데이터 검증**: 전화번호 형식, 필수 필드 검증

#### 3. 권한 관리 시스템
- **역할 기반**: ADMIN, USER, GUEST 권한
- **권한 확인**: 사용자별 권한 조회 및 검증
- **관리자 기능**: 관리자 권한 확인

#### 4. 인증 시스템
- **로그인**: 사용자명/비밀번호 인증
- **세션 관리**: 로그인 상태 확인
- **접근 제어**: 사용자 접근 권한 검증

### 🔧 기술적 특징

#### 1. 계층별 아키텍처
- **Controller**: REST API 엔드포인트 제공
- **Service**: 비즈니스 로직 처리
- **DAO**: 데이터 접근 로직
- **Mapper**: MyBatis SQL 매핑

#### 2. 데이터 검증
- **입력 검증**: 이메일, 전화번호, 사용자명 형식 검증
- **비즈니스 검증**: 중복 확인, 권한 검증
- **데이터 무결성**: 외래키 관계 유지

#### 3. 보안 기능
- **비밀번호 해싱**: SHA-256 알고리즘
- **입력 검증**: SQL Injection 방지
- **권한 기반 접근**: 역할별 접근 제어

#### 4. 유틸리티 기능
- **PasswordUtils**: 비밀번호 해싱 및 검증
- **ValidationUtils**: 데이터 형식 검증
- **Constants**: 상수 관리
- **UserRoleEnum**: 권한 열거형

### 📊 데이터 모델

#### 1. User (회원)
- 기본 회원 정보 (ID, 사용자명, 이메일, 비밀번호)
- 상태 관리 (ACTIVE, INACTIVE, DELETED)
- 생성/수정 시간 추적

#### 2. UserProfile (프로필)
- 상세 개인 정보 (이름, 전화번호, 주소 등)
- User와 1:1 관계
- 선택적 정보 (생년월일, 성별)

#### 3. UserRole (권한)
- 사용자별 권한 정보
- User와 1:N 관계
- 역할 코드 및 설명

### 🚀 API 특징

#### 1. RESTful 설계
- 표준 HTTP 메서드 사용 (GET, POST, PUT, DELETE)
- 일관된 URL 구조
- JSON 기반 데이터 교환

#### 2. 응답 형식
- 통일된 응답 구조 (success, message, data)
- 적절한 HTTP 상태 코드
- 상세한 오류 메시지

#### 3. 샘플 데이터
- 애플리케이션 시작 시 자동 생성
- 테스트용 사용자 및 권한 데이터
- 즉시 API 테스트 가능

## 응답 형식

모든 API는 일관된 응답 형식을 사용합니다:

### 성공 응답
```json
{
  "success": true,
  "message": "작업이 성공적으로 완료되었습니다",
  "data": { ... }
}
```

### 오류 응답
```json
{
  "success": false,
  "message": "오류 메시지"
}
```

## 개발 환경 설정

### 필수 요구사항
- Java 17 이상
- Maven 3.6 이상

### IDE 설정
- IntelliJ IDEA 또는 Eclipse 사용 권장
- Spring Boot 플러그인 설치
- Lombok 플러그인 설치 (선택사항)

## 라이센스

이 프로젝트는 교육 및 학습 목적으로 제작되었습니다.
