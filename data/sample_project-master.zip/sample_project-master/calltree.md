# Spring Boot Sample Project - Call Tree

이 문서는 스프링부트 샘플 프로젝트의 API 엔드포인트별 콜트리(call tree)를 정리한 것입니다.

## 📋 콜트리 구조

```
HTTP Request
    ↓
Controller (REST API)
    ↓
Service (Business Logic)
    ↓
DAO (Data Access)
    ↓
Mapper (MyBatis)
    ↓
Database (H2)
```

---

## 🔐 인증 관리 API (`/api/auth`)

### 1. POST `/api/auth/login`
```
POST /api/auth/login
    ↓
AuthController.login()
    ↓
AuthService.login()
    ↓
UserDAO.findUserByUsername()
    ↓
UserMapper.selectUserByUsername()
    ↓
UserRoleDAO.findUserRolesByUserId()
    ↓
UserRoleMapper.selectUserRolesByUserId()
    ↓
H2 Database
```

### 2. GET `/api/auth/profile/{userId}`
```
GET /api/auth/profile/{userId}
    ↓
AuthController.getUserProfile()
    ↓
AuthService.getUserProfile()
    ↓
UserDAO.findUserById()
    ↓
UserMapper.selectUserById()
    ↓
UserProfileDAO.findUserProfileByUserId()
    ↓
UserProfileMapper.selectUserProfileByUserId()
    ↓
UserRoleDAO.findUserRolesByUserId()
    ↓
UserRoleMapper.selectUserRolesByUserId()
    ↓
H2 Database
```

### 3. GET `/api/auth/check-role/{userId}`
```
GET /api/auth/check-role/{userId}?roleCode=ADMIN
    ↓
AuthController.checkUserRole()
    ↓
AuthService.hasRole()
    ↓
UserRoleDAO.hasRole()
    ↓
UserRoleMapper.selectUserRoleByUserIdAndRoleCode()
    ↓
H2 Database
```

### 4. GET `/api/auth/check-admin/{userId}`
```
GET /api/auth/check-admin/{userId}
    ↓
AuthController.checkAdminRole()
    ↓
AuthService.isAdmin()
    ↓
AuthService.hasRole()
    ↓
UserRoleDAO.hasRole()
    ↓
UserRoleMapper.selectUserRoleByUserIdAndRoleCode()
    ↓
H2 Database
```

### 5. POST `/api/auth/validate-access/{userId}`
```
POST /api/auth/validate-access/{userId}
    ↓
AuthController.validateUserAccess()
    ↓
AuthService.validateUserAccess()
    ↓
UserDAO.findUserById()
    ↓
UserMapper.selectUserById()
    ↓
H2 Database
```

---

## 👥 회원 관리 API (`/api/users`)

### 1. POST `/api/users`
```
POST /api/users
    ↓
UserController.createUser()
    ↓
UserService.createUser()
    ↓
ValidationUtils.isValidUsername()
    ↓
ValidationUtils.isValidEmail()
    ↓
ValidationUtils.isValidPassword()
    ↓
UserDAO.isUsernameExists()
    ↓
UserMapper.selectUserByUsername()
    ↓
UserDAO.isEmailExists()
    ↓
UserMapper.selectUserByEmail()
    ↓
PasswordUtils.simpleHash()
    ↓
UserDAO.createUser()
    ↓
UserMapper.insertUser()
    ↓
UserRoleDAO.createUserRole()
    ↓
UserRoleMapper.insertUserRole()
    ↓
H2 Database
```

### 2. GET `/api/users/{id}`
```
GET /api/users/{id}
    ↓
UserController.getUserById()
    ↓
UserService.getUserById()
    ↓
UserDAO.findUserById()
    ↓
UserMapper.selectUserById()
    ↓
H2 Database
```

### 3. GET `/api/users`
```
GET /api/users
    ↓
UserController.getAllUsers()
    ↓
UserService.getAllUsers()
    ↓
UserDAO.findAllUsers()
    ↓
UserMapper.selectAllUsers()
    ↓
H2 Database
```

### 4. PUT `/api/users/{id}`
```
PUT /api/users/{id}
    ↓
UserController.updateUser()
    ↓
UserService.updateUser()
    ↓
UserService.getUserById()
    ↓
UserDAO.findUserById()
    ↓
UserMapper.selectUserById()
    ↓
ValidationUtils.isNotEmpty()
    ↓
UserDAO.isUsernameExists()
    ↓
UserMapper.selectUserByUsername()
    ↓
UserDAO.isEmailExists()
    ↓
UserMapper.selectUserByEmail()
    ↓
PasswordUtils.simpleHash()
    ↓
UserDAO.updateUser()
    ↓
UserMapper.updateUser()
    ↓
H2 Database
```

### 5. DELETE `/api/users/{id}`
```
DELETE /api/users/{id}
    ↓
UserController.deleteUser()
    ↓
UserService.deleteUser()
    ↓
UserService.getUserById()
    ↓
UserDAO.findUserById()
    ↓
UserProfileDAO.deleteUserProfileByUserId()
    ↓
UserProfileMapper.deleteUserProfileByUserId()
    ↓
UserRoleDAO.deleteUserRolesByUserId()
    ↓
UserRoleMapper.deleteUserRolesByUserId()
    ↓
UserDAO.deleteUser()
    ↓
UserMapper.deleteUser()
    ↓
H2 Database
```

### 6. PUT `/api/users/{id}/status`
```
PUT /api/users/{id}/status
    ↓
UserController.updateUserStatus()
    ↓
UserService.updateUserStatus()
    ↓
UserService.getUserById()
    ↓
UserDAO.findUserById()
    ↓
UserMapper.selectUserById()
    ↓
UserDAO.updateUserStatus()
    ↓
UserMapper.updateUserStatus()
    ↓
H2 Database
```

---

## 👤 프로필 관리 API (`/api/users/{id}/profile`)

### 1. POST `/api/users/{id}/profile`
```
POST /api/users/{id}/profile
    ↓
UserController.createUserProfile()
    ↓
UserService.createUserProfile()
    ↓
UserService.getUserById()
    ↓
UserDAO.findUserById()
    ↓
UserMapper.selectUserById()
    ↓
UserProfileDAO.findUserProfileByUserId()
    ↓
UserProfileMapper.selectUserProfileByUserId()
    ↓
UserProfileDAO.createUserProfile()
    ↓
UserProfileMapper.insertUserProfile()
    ↓
H2 Database
```

### 2. GET `/api/users/{id}/profile`
```
GET /api/users/{id}/profile
    ↓
UserController.getUserProfile()
    ↓
UserService.getUserProfile()
    ↓
UserService.getUserById()
    ↓
UserDAO.findUserById()
    ↓
UserMapper.selectUserById()
    ↓
UserProfileDAO.findUserProfileByUserId()
    ↓
UserProfileMapper.selectUserProfileByUserId()
    ↓
H2 Database
```

### 3. PUT `/api/users/{id}/profile`
```
PUT /api/users/{id}/profile
    ↓
UserController.updateUserProfile()
    ↓
UserService.updateUserProfile()
    ↓
UserService.getUserProfile()
    ↓
UserService.getUserById()
    ↓
UserDAO.findUserById()
    ↓
UserProfileDAO.findUserProfileByUserId()
    ↓
UserProfileMapper.selectUserProfileByUserId()
    ↓
ValidationUtils.isNotEmpty()
    ↓
ValidationUtils.isValidPhoneNumber()
    ↓
UserProfileDAO.updateUserProfile()
    ↓
UserProfileMapper.updateUserProfile()
    ↓
H2 Database
```

---

## 🔧 유틸리티 클래스

### PasswordUtils
- `generateSalt()`: 랜덤 솔트 생성
- `hashPassword()`: 비밀번호 해싱
- `verifyPassword()`: 비밀번호 검증
- `simpleHash()`: 간단한 해싱 (SHA-256)

### ValidationUtils
- `isValidEmail()`: 이메일 형식 검증
- `isValidUsername()`: 사용자명 형식 검증
- `isValidPassword()`: 비밀번호 강도 검증
- `isValidPhoneNumber()`: 전화번호 형식 검증
- `isEmpty()` / `isNotEmpty()`: 문자열 검증

### Constants
- HTTP 상태 메시지
- 사용자 상태 상수
- 사용자 권한 상수
- 검증 메시지
- API 엔드포인트 경로

---

## 📊 데이터베이스 스키마

### users 테이블
- id (PK)
- username (UNIQUE)
- email (UNIQUE)
- password
- status
- created_at
- updated_at

### user_profiles 테이블
- id (PK)
- user_id (FK)
- first_name
- last_name
- phone_number
- address
- birth_date
- gender
- created_at
- updated_at

### user_roles 테이블
- id (PK)
- user_id (FK)
- role_code
- role_name
- description
- created_at
- updated_at

---

## 🔄 트랜잭션 흐름

### 회원 생성 시
1. 사용자 정보 검증
2. 중복 검사 (username, email)
3. 비밀번호 해싱
4. 사용자 저장
5. 기본 권한 할당

### 회원 삭제 시
1. 사용자 존재 확인
2. 관련 프로필 삭제
3. 관련 권한 삭제
4. 사용자 삭제

### 로그인 시
1. 사용자명으로 사용자 조회
2. 계정 상태 확인
3. 비밀번호 검증
4. 권한 정보 조회
5. 로그인 응답 생성
