package sg.sample.model;

import java.time.LocalDateTime;

/**
 * 사용자 권한 엔티티 클래스
 * 사용자의 권한 정보를 담는 모델 클래스입니다.
 * 
 * @author Sample Project
 * @version 1.0.0
 * @since 2024
 */
public class UserRole {
    /** 권한 고유 ID */
    private Long id;
    /** 사용자 ID (외래키) */
    private Long userId;
    /** 권한 코드 (ADMIN, USER, GUEST) */
    private String roleCode;
    /** 권한명 */
    private String roleName;
    /** 권한 설명 */
    private String description;
    /** 생성일시 */
    private LocalDateTime createdAt;
    /** 수정일시 */
    private LocalDateTime updatedAt;
    
    /**
     * 기본 생성자
     */
    public UserRole() {}
    
    /**
     * 권한 생성자
     * 
     * @param userId 사용자 ID
     * @param roleCode 권한 코드
     * @param roleName 권한명
     */
    public UserRole(Long userId, String roleCode, String roleName) {
        this.userId = userId;
        this.roleCode = roleCode;
        this.roleName = roleName;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    
    // ==================== Getters and Setters ====================
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public Long getUserId() {
        return userId;
    }
    
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    
    public String getRoleCode() {
        return roleCode;
    }
    
    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }
    
    public String getRoleName() {
        return roleName;
    }
    
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    @Override
    public String toString() {
        return "UserRole{" +
                "id=" + id +
                ", userId=" + userId +
                ", roleCode='" + roleCode + '\'' +
                ", roleName='" + roleName + '\'' +
                ", description='" + description + '\'' +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
                '}';
    }
}
