package sg.sample.co.utils;

import java.util.regex.Pattern;

/**
 * 데이터 검증 관련 유틸리티 클래스
 * 이메일, 사용자명, 비밀번호, 전화번호 등의 형식 검증을 제공합니다.
 * 
 * @author Sample Project
 * @version 1.0.0
 * @since 2024
 */
public class ValidationUtils {
    
    /** 이메일 형식 검증을 위한 정규표현식 패턴 */
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
    );
    
    /** 사용자명 형식 검증을 위한 정규표현식 패턴 (3-20자, 영숫자와 언더스코어만) */
    private static final Pattern USERNAME_PATTERN = Pattern.compile(
        "^[a-zA-Z0-9_]{3,20}$"
    );
    
    /**
     * 이메일 형식 검증
     * 
     * @param email 검증할 이메일 주소
     * @return 유효한 이메일 형식이면 true, 아니면 false
     */
    public static boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        return EMAIL_PATTERN.matcher(email.trim()).matches();
    }
    
    /**
     * 사용자명 형식 검증 (3-20자, 영숫자와 언더스코어만 허용)
     * 
     * @param username 검증할 사용자명
     * @return 유효한 사용자명 형식이면 true, 아니면 false
     */
    public static boolean isValidUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            return false;
        }
        return USERNAME_PATTERN.matcher(username.trim()).matches();
    }
    
    /**
     * 비밀번호 강도 검증 (최소 6자)
     * 
     * @param password 검증할 비밀번호
     * @return 6자 이상이면 true, 아니면 false
     */
    public static boolean isValidPassword(String password) {
        return password != null && password.length() >= 6;
    }
    
    /**
     * 문자열이 null이거나 비어있는지 확인
     * 
     * @param str 검증할 문자열
     * @return null이거나 비어있으면 true, 아니면 false
     */
    public static boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }
    
    /**
     * 문자열이 null이 아니고 비어있지 않은지 확인
     * 
     * @param str 검증할 문자열
     * @return null이 아니고 비어있지 않으면 true, 아니면 false
     */
    public static boolean isNotEmpty(String str) {
        return !isEmpty(str);
    }
    
    /**
     * 전화번호 형식 검증 (간단한 검증)
     * 
     * @param phoneNumber 검증할 전화번호
     * @return 10-15자리 숫자이면 true, 아니면 false
     */
    public static boolean isValidPhoneNumber(String phoneNumber) {
        if (isEmpty(phoneNumber)) {
            return false;
        }
        // 모든 비숫자 문자 제거
        String digitsOnly = phoneNumber.replaceAll("\\D", "");
        return digitsOnly.length() >= 10 && digitsOnly.length() <= 15;
    }
}
