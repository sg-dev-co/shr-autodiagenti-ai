package sg.sample.mapper;

import org.apache.ibatis.annotations.Mapper;
import sg.sample.model.UserProfile;

import java.util.List;

/**
 * 사용자 프로필 데이터베이스 매퍼 인터페이스
 * MyBatis를 사용하여 사용자 프로필 관련 SQL 쿼리를 처리합니다.
 * 
 * @author Sample Project
 * @version 1.0.0
 * @since 2024
 */
@Mapper
public interface UserProfileMapper {
    
    /**
     * 사용자 프로필 생성
     * 
     * @param userProfile 생성할 프로필 정보
     * @return 생성된 행 수
     */
    int insertUserProfile(UserProfile userProfile);
    
    /**
     * ID로 프로필 조회
     * 
     * @param id 조회할 프로필 ID
     * @return 프로필 정보 (없으면 null)
     */
    UserProfile selectUserProfileById(Long id);
    
    /**
     * 사용자 ID로 프로필 조회
     * 
     * @param userId 조회할 사용자 ID
     * @return 프로필 정보 (없으면 null)
     */
    UserProfile selectUserProfileByUserId(Long userId);
    
    /**
     * 전체 프로필 목록 조회
     * 
     * @return 전체 프로필 목록
     */
    List<UserProfile> selectAllUserProfiles();
    
    /**
     * 프로필 정보 수정
     * 
     * @param userProfile 수정할 프로필 정보
     * @return 수정된 행 수
     */
    int updateUserProfile(UserProfile userProfile);
    
    /**
     * 프로필 삭제
     * 
     * @param id 삭제할 프로필 ID
     * @return 삭제된 행 수
     */
    int deleteUserProfile(Long id);
    
    /**
     * 사용자 ID로 프로필 삭제
     * 
     * @param userId 삭제할 사용자 ID
     * @return 삭제된 행 수
     */
    int deleteUserProfileByUserId(Long userId);
}
