package sg.sample.co.constants;

/**
 * 애플리케이션에서 사용되는 상수들을 정의하는 클래스
 * 
 * @author Sample Project
 * @version 1.0.0
 * @since 2024
 */
public class Constants {
    
    // ==================== HTTP Status Messages ====================
    /** 성공 메시지 */
    public static final String SUCCESS_MESSAGE = "Success";
    /** 오류 메시지 */
    public static final String ERROR_MESSAGE = "Error";
    /** 찾을 수 없음 메시지 */
    public static final String NOT_FOUND_MESSAGE = "Not Found";
    
    // ==================== User Status ====================
    /** 사용자 활성 상태 */
    public static final String USER_STATUS_ACTIVE = "ACTIVE";
    /** 사용자 비활성 상태 */
    public static final String USER_STATUS_INACTIVE = "INACTIVE";
    /** 사용자 삭제 상태 */
    public static final String USER_STATUS_DELETED = "DELETED";
    
    // ==================== User Roles ====================
    /** 관리자 권한 */
    public static final String ROLE_ADMIN = "ADMIN";
    /** 일반 사용자 권한 */
    public static final String ROLE_USER = "USER";
    /** 게스트 권한 */
    public static final String ROLE_GUEST = "GUEST";
    
    // ==================== Validation Messages ====================
    /** 사용자명 필수 검증 메시지 */
    public static final String VALIDATION_USERNAME_REQUIRED = "Username is required";
    /** 이메일 필수 검증 메시지 */
    public static final String VALIDATION_EMAIL_REQUIRED = "Email is required";
    /** 비밀번호 필수 검증 메시지 */
    public static final String VALIDATION_PASSWORD_REQUIRED = "Password is required";
    
    // ==================== API Endpoints ====================
    /** API 기본 경로 */
    public static final String API_BASE_PATH = "/api";
    /** 사용자 관리 API 경로 */
    public static final String API_USERS_PATH = API_BASE_PATH + "/users";
    /** 인증 관리 API 경로 */
    public static final String API_AUTH_PATH = API_BASE_PATH + "/auth";
    
    /**
     * Private 생성자 - 인스턴스화 방지
     */
    private Constants() {
        // Private constructor to prevent instantiation
    }
}
