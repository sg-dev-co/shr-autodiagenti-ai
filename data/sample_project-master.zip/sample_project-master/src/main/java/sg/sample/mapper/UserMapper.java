package sg.sample.mapper;

import org.apache.ibatis.annotations.Mapper;
import sg.sample.model.User;

import java.util.List;

/**
 * 사용자 데이터베이스 매퍼 인터페이스
 * MyBatis를 사용하여 사용자 관련 SQL 쿼리를 처리합니다.
 * 
 * @author Sample Project
 * @version 1.0.0
 * @since 2024
 */
@Mapper
public interface UserMapper {
    
    /**
     * 사용자 생성
     * 
     * @param user 생성할 사용자 정보
     * @return 생성된 행 수
     */
    int insertUser(User user);
    
    /**
     * ID로 사용자 조회
     * 
     * @param id 조회할 사용자 ID
     * @return 사용자 정보 (없으면 null)
     */
    User selectUserById(Long id);
    
    /**
     * 사용자명으로 사용자 조회
     * 
     * @param username 조회할 사용자명
     * @return 사용자 정보 (없으면 null)
     */
    User selectUserByUsername(String username);
    
    /**
     * 이메일로 사용자 조회
     * 
     * @param email 조회할 이메일
     * @return 사용자 정보 (없으면 null)
     */
    User selectUserByEmail(String email);
    
    /**
     * 전체 사용자 목록 조회
     * 
     * @return 전체 사용자 목록
     */
    List<User> selectAllUsers();
    
    /**
     * 사용자 정보 수정
     * 
     * @param user 수정할 사용자 정보
     * @return 수정된 행 수
     */
    int updateUser(User user);
    
    /**
     * 사용자 삭제
     * 
     * @param id 삭제할 사용자 ID
     * @return 삭제된 행 수
     */
    int deleteUser(Long id);
    
    /**
     * 사용자 상태 수정
     * 
     * @param id 수정할 사용자 ID
     * @param status 새로운 상태
     * @return 수정된 행 수
     */
    int updateUserStatus(Long id, String status);
}
