package sg.sample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sg.sample.co.constants.Constants;
import sg.sample.service.AuthService;

import java.util.HashMap;
import java.util.Map;

/**
 * 인증 관련 REST API 컨트롤러
 * 로그인, 프로필 조회, 권한 확인 등의 인증 기능을 제공합니다.
 * 
 * @author Sample Project
 * @version 1.0.0
 * @since 2024
 */
@RestController
@RequestMapping(Constants.API_AUTH_PATH)
public class AuthController {
    
    /** 인증 서비스 */
    @Autowired
    private AuthService authService;
    
    /**
     * 사용자 로그인 API
     * 
     * @param loginRequest 로그인 요청 데이터 (username, password)
     * @return 로그인 결과 (성공 시 사용자 정보, 실패 시 오류 메시지)
     */
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> loginRequest) {
        try {
            // 요청 데이터 추출
            String username = loginRequest.get("username");
            String password = loginRequest.get("password");
            
            // 필수 파라미터 검증
            if (username == null || password == null) {
                throw new IllegalArgumentException("Username and password are required");
            }
            
            // 인증 서비스 호출
            Map<String, Object> loginResult = authService.login(username, password);
            
            // 성공 응답 생성
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Login successful");
            response.put("data", loginResult);
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            // 인증 실패 응답
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }
    }
    
    /**
     * 사용자 프로필 조회 API
     * 
     * @param userId 조회할 사용자 ID
     * @return 사용자 프로필 정보 (성공 시 프로필 데이터, 실패 시 오류 메시지)
     */
    @GetMapping("/profile/{userId}")
    public ResponseEntity<Map<String, Object>> getUserProfile(@PathVariable Long userId) {
        try {
            // 프로필 정보 조회
            Map<String, Object> profile = authService.getUserProfile(userId);
            
            // 성공 응답 생성
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Profile retrieved successfully");
            response.put("data", profile);
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            // 사용자를 찾을 수 없는 경우
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }
    
    /**
     * 사용자 권한 확인 API
     * 
     * @param userId 확인할 사용자 ID
     * @param roleCode 확인할 권한 코드
     * @return 권한 확인 결과 (성공 시 권한 보유 여부, 실패 시 오류 메시지)
     */
    @GetMapping("/check-role/{userId}")
    public ResponseEntity<Map<String, Object>> checkUserRole(@PathVariable Long userId, @RequestParam String roleCode) {
        try {
            // 권한 확인
            boolean hasRole = authService.hasRole(userId, roleCode);
            
            // 성공 응답 생성
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Role check completed");
            response.put("data", Map.of(
                "userId", userId,
                "roleCode", roleCode,
                "hasRole", hasRole
            ));
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            // 오류 응답
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            
            return ResponseEntity.badRequest().body(response);
        }
    }
    
    /**
     * 관리자 권한 확인 API
     * 
     * @param userId 확인할 사용자 ID
     * @return 관리자 권한 확인 결과 (성공 시 관리자 여부, 실패 시 오류 메시지)
     */
    @GetMapping("/check-admin/{userId}")
    public ResponseEntity<Map<String, Object>> checkAdminRole(@PathVariable Long userId) {
        try {
            // 관리자 권한 확인
            boolean isAdmin = authService.isAdmin(userId);
            
            // 성공 응답 생성
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Admin check completed");
            response.put("data", Map.of(
                "userId", userId,
                "isAdmin", isAdmin
            ));
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            // 오류 응답
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            
            return ResponseEntity.badRequest().body(response);
        }
    }
    
    /**
     * 사용자 접근 권한 검증 API
     * 
     * @param userId 검증할 사용자 ID
     * @return 접근 권한 검증 결과 (성공 시 검증 완료, 실패 시 오류 메시지)
     */
    @PostMapping("/validate-access/{userId}")
    public ResponseEntity<Map<String, Object>> validateUserAccess(@PathVariable Long userId) {
        try {
            // 사용자 접근 권한 검증
            authService.validateUserAccess(userId);
            
            // 성공 응답 생성
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "User access validated successfully");
            response.put("data", Map.of("userId", userId));
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            // 접근 권한이 없는 경우
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
        }
    }
}
