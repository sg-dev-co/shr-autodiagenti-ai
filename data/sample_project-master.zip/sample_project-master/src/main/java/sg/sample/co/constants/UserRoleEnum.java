package sg.sample.co.constants;

/**
 * 사용자 권한을 정의하는 열거형
 * 
 * @author Sample Project
 * @version 1.0.0
 * @since 2024
 */
public enum UserRoleEnum {
    /** 관리자 권한 */
    ADMIN("ADMIN", "Administrator"),
    /** 일반 사용자 권한 */
    USER("USER", "Regular User"),
    /** 게스트 권한 */
    GUEST("GUEST", "Guest User");
    
    /** 권한 코드 */
    private final String code;
    /** 권한 설명 */
    private final String description;
    
    /**
     * 생성자
     * 
     * @param code 권한 코드
     * @param description 권한 설명
     */
    UserRoleEnum(String code, String description) {
        this.code = code;
        this.description = description;
    }
    
    /**
     * 권한 코드 반환
     * 
     * @return 권한 코드
     */
    public String getCode() {
        return code;
    }
    
    /**
     * 권한 설명 반환
     * 
     * @return 권한 설명
     */
    public String getDescription() {
        return description;
    }
    
    /**
     * 권한 코드로 열거형 값 찾기
     * 
     * @param code 권한 코드
     * @return 해당하는 UserRoleEnum 값
     * @throws IllegalArgumentException 알 수 없는 권한 코드인 경우
     */
    public static UserRoleEnum fromCode(String code) {
        for (UserRoleEnum role : values()) {
            if (role.code.equals(code)) {
                return role;
            }
        }
        throw new IllegalArgumentException("Unknown role code: " + code);
    }
}
