package sg.sample.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import sg.sample.mapper.UserMapper;
import sg.sample.model.User;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 사용자 데이터 접근 객체 (DAO)
 * 사용자 관련 데이터베이스 작업을 처리합니다.
 * 
 * @author Sample Project
 * @version 1.0.0
 * @since 2024
 */
@Repository
public class UserDAO {
    
    /** 사용자 매퍼 인터페이스 */
    @Autowired
    private UserMapper userMapper;
    
    /**
     * 사용자 생성
     * 
     * @param user 생성할 사용자 정보
     * @return 생성된 행 수
     */
    public int createUser(User user) {
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
        return userMapper.insertUser(user);
    }
    
    /**
     * ID로 사용자 조회
     * 
     * @param id 조회할 사용자 ID
     * @return 사용자 정보 (없으면 null)
     */
    public User findUserById(Long id) {
        return userMapper.selectUserById(id);
    }
    
    /**
     * 사용자명으로 사용자 조회
     * 
     * @param username 조회할 사용자명
     * @return 사용자 정보 (없으면 null)
     */
    public User findUserByUsername(String username) {
        return userMapper.selectUserByUsername(username);
    }
    
    /**
     * 이메일로 사용자 조회
     * 
     * @param email 조회할 이메일
     * @return 사용자 정보 (없으면 null)
     */
    public User findUserByEmail(String email) {
        return userMapper.selectUserByEmail(email);
    }
    
    /**
     * 전체 사용자 목록 조회
     * 
     * @return 전체 사용자 목록
     */
    public List<User> findAllUsers() {
        return userMapper.selectAllUsers();
    }
    
    /**
     * 사용자 정보 수정
     * 
     * @param user 수정할 사용자 정보
     * @return 수정된 행 수
     */
    public int updateUser(User user) {
        user.setUpdatedAt(LocalDateTime.now());
        return userMapper.updateUser(user);
    }
    
    /**
     * 사용자 삭제
     * 
     * @param id 삭제할 사용자 ID
     * @return 삭제된 행 수
     */
    public int deleteUser(Long id) {
        return userMapper.deleteUser(id);
    }
    
    /**
     * 사용자 상태 수정
     * 
     * @param id 수정할 사용자 ID
     * @param status 새로운 상태
     * @return 수정된 행 수
     */
    public int updateUserStatus(Long id, String status) {
        return userMapper.updateUserStatus(id, status);
    }
    
    /**
     * 사용자명 중복 확인
     * 
     * @param username 확인할 사용자명
     * @return 중복이면 true, 아니면 false
     */
    public boolean isUsernameExists(String username) {
        return userMapper.selectUserByUsername(username) != null;
    }
    
    /**
     * 이메일 중복 확인
     * 
     * @param email 확인할 이메일
     * @return 중복이면 true, 아니면 false
     */
    public boolean isEmailExists(String email) {
        return userMapper.selectUserByEmail(email) != null;
    }
}
