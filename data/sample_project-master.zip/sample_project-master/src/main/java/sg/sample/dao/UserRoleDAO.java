package sg.sample.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import sg.sample.mapper.UserRoleMapper;
import sg.sample.model.UserRole;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public class UserRoleDAO {
    
    @Autowired
    private UserRoleMapper userRoleMapper;
    
    public int createUserRole(UserRole userRole) {
        userRole.setCreatedAt(LocalDateTime.now());
        userRole.setUpdatedAt(LocalDateTime.now());
        return userRoleMapper.insertUserRole(userRole);
    }
    
    public UserRole findUserRoleById(Long id) {
        return userRoleMapper.selectUserRoleById(id);
    }
    
    public List<UserRole> findUserRolesByUserId(Long userId) {
        return userRoleMapper.selectUserRolesByUserId(userId);
    }
    
    public UserRole findUserRoleByUserIdAndRoleCode(Long userId, String roleCode) {
        return userRoleMapper.selectUserRoleByUserIdAndRoleCode(userId, roleCode);
    }
    
    public List<UserRole> findAllUserRoles() {
        return userRoleMapper.selectAllUserRoles();
    }
    
    public int updateUserRole(UserRole userRole) {
        userRole.setUpdatedAt(LocalDateTime.now());
        return userRoleMapper.updateUserRole(userRole);
    }
    
    public int deleteUserRole(Long id) {
        return userRoleMapper.deleteUserRole(id);
    }
    
    public int deleteUserRolesByUserId(Long userId) {
        return userRoleMapper.deleteUserRolesByUserId(userId);
    }
    
    public boolean hasRole(Long userId, String roleCode) {
        return userRoleMapper.selectUserRoleByUserIdAndRoleCode(userId, roleCode) != null;
    }
}
