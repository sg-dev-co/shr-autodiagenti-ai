package sg.sample.co.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * 비밀번호 관련 유틸리티 클래스
 * 비밀번호 해싱, 솔트 생성, 검증 기능을 제공합니다.
 * 
 * @author Sample Project
 * @version 1.0.0
 * @since 2024
 */
public class PasswordUtils {
    
    /** 해시 알고리즘 (SHA-256) */
    private static final String HASH_ALGORITHM = "SHA-256";
    /** 솔트 길이 (바이트) */
    private static final int SALT_LENGTH = 16;
    
    /**
     * 랜덤 솔트 생성
     * 
     * @return Base64로 인코딩된 랜덤 솔트 문자열
     */
    public static String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[SALT_LENGTH];
        random.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }
    
    /**
     * 솔트를 사용하여 비밀번호를 SHA-256으로 해싱
     * 
     * @param password 원본 비밀번호
     * @param salt 솔트 문자열
     * @return Base64로 인코딩된 해시된 비밀번호
     * @throws RuntimeException 해시 알고리즘을 찾을 수 없는 경우
     */
    public static String hashPassword(String password, String salt) {
        try {
            MessageDigest md = MessageDigest.getInstance(HASH_ALGORITHM);
            md.update(salt.getBytes());
            byte[] hashedPassword = md.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hashedPassword);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Hash algorithm not found", e);
        }
    }
    
    /**
     * 저장된 해시와 솔트를 사용하여 비밀번호 검증
     * 
     * @param password 검증할 비밀번호
     * @param storedHash 저장된 해시
     * @param storedSalt 저장된 솔트
     * @return 비밀번호가 일치하면 true, 아니면 false
     */
    public static boolean verifyPassword(String password, String storedHash, String storedSalt) {
        String computedHash = hashPassword(password, storedSalt);
        return computedHash.equals(storedHash);
    }
    
    /**
     * 간단한 해시 생성 (데모용, 프로덕션에서는 사용하지 않음)
     * 
     * @param password 원본 비밀번호
     * @return Base64로 인코딩된 해시된 비밀번호
     * @throws RuntimeException 해시 알고리즘을 찾을 수 없는 경우
     */
    public static String simpleHash(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance(HASH_ALGORITHM);
            byte[] hashedPassword = md.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hashedPassword);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Hash algorithm not found", e);
        }
    }
}
