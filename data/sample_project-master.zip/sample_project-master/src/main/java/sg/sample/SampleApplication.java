package sg.sample;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 스프링부트 메인 애플리케이션 클래스
 * 
 * @author Sample Project
 * @version 1.0.0
 * @since 2024
 */
@SpringBootApplication
@MapperScan("sg.sample.mapper") // MyBatis 매퍼 인터페이스 스캔 설정
public class SampleApplication {

    /**
     * 애플리케이션 시작점
     * 
     * @param args 명령행 인수
     */
    public static void main(String[] args) {
        SpringApplication.run(SampleApplication.class, args);
    }
}
