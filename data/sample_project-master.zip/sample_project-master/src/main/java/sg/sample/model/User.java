package sg.sample.model;

import java.time.LocalDateTime;

/**
 * 사용자 엔티티 클래스
 * 사용자의 기본 정보를 담는 모델 클래스입니다.
 * 
 * @author Sample Project
 * @version 1.0.0
 * @since 2024
 */
public class User {
    /** 사용자 고유 ID */
    private Long id;
    /** 사용자명 */
    private String username;
    /** 이메일 주소 */
    private String email;
    /** 비밀번호 (해시된 값) */
    private String password;
    /** 사용자 상태 (ACTIVE, INACTIVE, DELETED) */
    private String status;
    /** 생성일시 */
    private LocalDateTime createdAt;
    /** 수정일시 */
    private LocalDateTime updatedAt;
    
    /**
     * 기본 생성자
     */
    public User() {}
    
    /**
     * 사용자 생성자
     * 
     * @param username 사용자명
     * @param email 이메일 주소
     * @param password 비밀번호
     */
    public User(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.status = "ACTIVE";
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    
    // ==================== Getters and Setters ====================
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", status='" + status + '\'' +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
                '}';
    }
}
