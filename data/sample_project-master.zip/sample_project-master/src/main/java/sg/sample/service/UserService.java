package sg.sample.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sg.sample.co.constants.Constants;
import sg.sample.co.utils.PasswordUtils;
import sg.sample.co.utils.ValidationUtils;
import sg.sample.dao.UserDAO;
import sg.sample.dao.UserProfileDAO;
import sg.sample.dao.UserRoleDAO;
import sg.sample.model.User;
import sg.sample.model.UserProfile;
import sg.sample.model.UserRole;

import java.util.List;

/**
 * 사용자 관리 비즈니스 로직을 처리하는 서비스 클래스
 * 사용자 CRUD, 프로필 관리 등의 사용자 관련 기능을 제공합니다.
 * 
 * @author Sample Project
 * @version 1.0.0
 * @since 2024
 */
@Service
public class UserService {
    
    /** 사용자 데이터 접근 객체 */
    @Autowired
    private UserDAO userDAO;
    
    /** 사용자 프로필 데이터 접근 객체 */
    @Autowired
    private UserProfileDAO userProfileDAO;
    
    /** 사용자 권한 데이터 접근 객체 */
    @Autowired
    private UserRoleDAO userRoleDAO;
    
    /**
     * 사용자 생성
     * 
     * @param user 생성할 사용자 정보
     * @return 생성된 사용자 정보
     * @throws IllegalArgumentException 유효하지 않은 데이터이거나 중복된 사용자명/이메일인 경우
     */
    public User createUser(User user) {
        // 데이터 검증
        if (!ValidationUtils.isValidUsername(user.getUsername())) {
            throw new IllegalArgumentException("Invalid username format");
        }
        if (!ValidationUtils.isValidEmail(user.getEmail())) {
            throw new IllegalArgumentException("Invalid email format");
        }
        if (!ValidationUtils.isValidPassword(user.getPassword())) {
            throw new IllegalArgumentException("Password must be at least 6 characters");
        }
        
        // 사용자명/이메일 중복 확인
        if (userDAO.isUsernameExists(user.getUsername())) {
            throw new IllegalArgumentException("Username already exists");
        }
        if (userDAO.isEmailExists(user.getEmail())) {
            throw new IllegalArgumentException("Email already exists");
        }
        
        // 비밀번호 해싱 및 상태 설정
        user.setPassword(PasswordUtils.simpleHash(user.getPassword()));
        user.setStatus(Constants.USER_STATUS_ACTIVE);
        
        // 사용자 생성
        userDAO.createUser(user);
        
        // 기본 사용자 권한 생성
        UserRole defaultRole = new UserRole(user.getId(), Constants.ROLE_USER, "Regular User");
        userRoleDAO.createUserRole(defaultRole);
        
        return user;
    }
    
    /**
     * ID로 사용자 조회
     * 
     * @param id 조회할 사용자 ID
     * @return 사용자 정보
     * @throws IllegalArgumentException 사용자가 존재하지 않는 경우
     */
    public User getUserById(Long id) {
        User user = userDAO.findUserById(id);
        if (user == null) {
            throw new IllegalArgumentException("User not found with id: " + id);
        }
        return user;
    }
    
    /**
     * 사용자명으로 사용자 조회
     * 
     * @param username 조회할 사용자명
     * @return 사용자 정보 (없으면 null)
     */
    public User getUserByUsername(String username) {
        return userDAO.findUserByUsername(username);
    }
    
    /**
     * 전체 사용자 목록 조회
     * 
     * @return 전체 사용자 목록
     */
    public List<User> getAllUsers() {
        return userDAO.findAllUsers();
    }
    
    /**
     * 사용자 정보 수정
     * 
     * @param id 수정할 사용자 ID
     * @param userUpdate 수정할 사용자 정보
     * @return 수정된 사용자 정보
     * @throws IllegalArgumentException 사용자가 존재하지 않거나 중복된 사용자명/이메일인 경우
     */
    public User updateUser(Long id, User userUpdate) {
        User existingUser = getUserById(id);
        
        // 사용자명 수정 (중복 확인)
        if (ValidationUtils.isNotEmpty(userUpdate.getUsername()) && 
            !userUpdate.getUsername().equals(existingUser.getUsername())) {
            if (userDAO.isUsernameExists(userUpdate.getUsername())) {
                throw new IllegalArgumentException("Username already exists");
            }
            existingUser.setUsername(userUpdate.getUsername());
        }
        
        // 이메일 수정 (중복 확인)
        if (ValidationUtils.isNotEmpty(userUpdate.getEmail()) && 
            !userUpdate.getEmail().equals(existingUser.getEmail())) {
            if (userDAO.isEmailExists(userUpdate.getEmail())) {
                throw new IllegalArgumentException("Email already exists");
            }
            existingUser.setEmail(userUpdate.getEmail());
        }
        
        // 비밀번호 수정 (해싱)
        if (ValidationUtils.isNotEmpty(userUpdate.getPassword())) {
            existingUser.setPassword(PasswordUtils.simpleHash(userUpdate.getPassword()));
        }
        
        // 상태 수정
        if (ValidationUtils.isNotEmpty(userUpdate.getStatus())) {
            existingUser.setStatus(userUpdate.getStatus());
        }
        
        userDAO.updateUser(existingUser);
        return existingUser;
    }
    
    /**
     * 사용자 삭제 (연관 데이터 포함)
     * 
     * @param id 삭제할 사용자 ID
     * @throws IllegalArgumentException 사용자가 존재하지 않는 경우
     */
    public void deleteUser(Long id) {
        User user = getUserById(id);
        
        // 연관 데이터 삭제 (프로필, 권한)
        userProfileDAO.deleteUserProfileByUserId(id);
        userRoleDAO.deleteUserRolesByUserId(id);
        
        // 사용자 삭제
        userDAO.deleteUser(id);
    }
    
    /**
     * 사용자 상태 수정
     * 
     * @param id 수정할 사용자 ID
     * @param status 새로운 상태
     * @throws IllegalArgumentException 사용자가 존재하지 않는 경우
     */
    public void updateUserStatus(Long id, String status) {
        getUserById(id); // 사용자 존재 확인
        userDAO.updateUserStatus(id, status);
    }
    
    /**
     * 사용자 프로필 생성
     * 
     * @param userId 프로필을 생성할 사용자 ID
     * @param profile 생성할 프로필 정보
     * @return 생성된 프로필 정보
     * @throws IllegalArgumentException 사용자가 존재하지 않거나 이미 프로필이 존재하는 경우
     */
    public UserProfile createUserProfile(Long userId, UserProfile profile) {
        getUserById(userId); // 사용자 존재 확인
        
        if (userProfileDAO.findUserProfileByUserId(userId) != null) {
            throw new IllegalArgumentException("User profile already exists for user: " + userId);
        }
        
        profile.setUserId(userId);
        userProfileDAO.createUserProfile(profile);
        return profile;
    }
    
    /**
     * 사용자 프로필 조회
     * 
     * @param userId 조회할 사용자 ID
     * @return 프로필 정보 (없으면 null)
     * @throws IllegalArgumentException 사용자가 존재하지 않는 경우
     */
    public UserProfile getUserProfile(Long userId) {
        getUserById(userId); // 사용자 존재 확인
        return userProfileDAO.findUserProfileByUserId(userId);
    }
    
    /**
     * 사용자 프로필 수정
     * 
     * @param userId 수정할 사용자 ID
     * @param profileUpdate 수정할 프로필 정보
     * @return 수정된 프로필 정보
     * @throws IllegalArgumentException 사용자가 존재하지 않거나 유효하지 않은 전화번호인 경우
     */
    public UserProfile updateUserProfile(Long userId, UserProfile profileUpdate) {
        UserProfile existingProfile = getUserProfile(userId);
        
        // 이름 수정
        if (ValidationUtils.isNotEmpty(profileUpdate.getFirstName())) {
            existingProfile.setFirstName(profileUpdate.getFirstName());
        }
        // 성 수정
        if (ValidationUtils.isNotEmpty(profileUpdate.getLastName())) {
            existingProfile.setLastName(profileUpdate.getLastName());
        }
        // 전화번호 수정 (형식 검증)
        if (ValidationUtils.isNotEmpty(profileUpdate.getPhoneNumber())) {
            if (!ValidationUtils.isValidPhoneNumber(profileUpdate.getPhoneNumber())) {
                throw new IllegalArgumentException("Invalid phone number format");
            }
            existingProfile.setPhoneNumber(profileUpdate.getPhoneNumber());
        }
        // 주소 수정
        if (ValidationUtils.isNotEmpty(profileUpdate.getAddress())) {
            existingProfile.setAddress(profileUpdate.getAddress());
        }
        // 생년월일 수정
        if (profileUpdate.getBirthDate() != null) {
            existingProfile.setBirthDate(profileUpdate.getBirthDate());
        }
        // 성별 수정
        if (ValidationUtils.isNotEmpty(profileUpdate.getGender())) {
            existingProfile.setGender(profileUpdate.getGender());
        }
        
        userProfileDAO.updateUserProfile(existingProfile);
        return existingProfile;
    }
}
