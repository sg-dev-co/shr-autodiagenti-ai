package sg.sample.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import sg.sample.mapper.UserProfileMapper;
import sg.sample.model.UserProfile;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public class UserProfileDAO {
    
    @Autowired
    private UserProfileMapper userProfileMapper;
    
    public int createUserProfile(UserProfile userProfile) {
        userProfile.setCreatedAt(LocalDateTime.now());
        userProfile.setUpdatedAt(LocalDateTime.now());
        return userProfileMapper.insertUserProfile(userProfile);
    }
    
    public UserProfile findUserProfileById(Long id) {
        return userProfileMapper.selectUserProfileById(id);
    }
    
    public UserProfile findUserProfileByUserId(Long userId) {
        return userProfileMapper.selectUserProfileByUserId(userId);
    }
    
    public List<UserProfile> findAllUserProfiles() {
        return userProfileMapper.selectAllUserProfiles();
    }
    
    public int updateUserProfile(UserProfile userProfile) {
        userProfile.setUpdatedAt(LocalDateTime.now());
        return userProfileMapper.updateUserProfile(userProfile);
    }
    
    public int deleteUserProfile(Long id) {
        return userProfileMapper.deleteUserProfile(id);
    }
    
    public int deleteUserProfileByUserId(Long userId) {
        return userProfileMapper.deleteUserProfileByUserId(userId);
    }
}
