package sg.sample.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sg.sample.co.constants.Constants;
import sg.sample.co.utils.PasswordUtils;
import sg.sample.dao.UserDAO;
import sg.sample.dao.UserProfileDAO;
import sg.sample.dao.UserRoleDAO;
import sg.sample.model.User;
import sg.sample.model.UserProfile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 인증 관련 비즈니스 로직을 처리하는 서비스 클래스
 * 로그인, 프로필 조회, 권한 확인 등의 인증 기능을 제공합니다.
 * 
 * @author Sample Project
 * @version 1.0.0
 * @since 2024
 */
@Service
public class AuthService {
    
    /** 사용자 데이터 접근 객체 */
    @Autowired
    private UserDAO userDAO;
    
    /** 사용자 프로필 데이터 접근 객체 */
    @Autowired
    private UserProfileDAO userProfileDAO;
    
    /** 사용자 권한 데이터 접근 객체 */
    @Autowired
    private UserRoleDAO userRoleDAO;
    
    /**
     * 사용자 로그인 처리
     * 
     * @param username 사용자명
     * @param password 비밀번호
     * @return 로그인 성공 시 사용자 정보와 권한 목록
     * @throws IllegalArgumentException 사용자가 존재하지 않거나 비밀번호가 틀리거나 계정이 비활성화된 경우
     */
    public Map<String, Object> login(String username, String password) {
        // 사용자명으로 사용자 조회
        User user = userDAO.findUserByUsername(username);
        if (user == null) {
            throw new IllegalArgumentException("Invalid username or password");
        }
        
        // 사용자 계정 상태 확인
        if (!Constants.USER_STATUS_ACTIVE.equals(user.getStatus())) {
            throw new IllegalArgumentException("User account is not active");
        }
        
        // 비밀번호 검증
        String hashedPassword = PasswordUtils.simpleHash(password);
        if (!hashedPassword.equals(user.getPassword())) {
            throw new IllegalArgumentException("Invalid username or password");
        }
        
        // 사용자 권한 목록 조회
        List<String> roles = userRoleDAO.findUserRolesByUserId(user.getId())
                .stream()
                .map(role -> role.getRoleCode())
                .toList();
        
        // 로그인 응답 생성
        Map<String, Object> response = new HashMap<>();
        response.put("userId", user.getId());
        response.put("username", user.getUsername());
        response.put("email", user.getEmail());
        response.put("status", user.getStatus());
        response.put("roles", roles);
        response.put("message", "Login successful");
        
        return response;
    }
    
    public Map<String, Object> getUserProfile(Long userId) {
        // Validate user exists
        User user = userDAO.findUserById(userId);
        if (user == null) {
            throw new IllegalArgumentException("User not found");
        }
        
        // Get user profile
        UserProfile profile = userProfileDAO.findUserProfileByUserId(userId);
        
        // Get user roles
        List<String> roles = userRoleDAO.findUserRolesByUserId(userId)
                .stream()
                .map(role -> role.getRoleCode())
                .toList();
        
        // Create response
        Map<String, Object> response = new HashMap<>();
        response.put("userId", user.getId());
        response.put("username", user.getUsername());
        response.put("email", user.getEmail());
        response.put("status", user.getStatus());
        response.put("roles", roles);
        
        if (profile != null) {
            response.put("firstName", profile.getFirstName());
            response.put("lastName", profile.getLastName());
            response.put("fullName", profile.getFullName());
            response.put("phoneNumber", profile.getPhoneNumber());
            response.put("address", profile.getAddress());
            response.put("birthDate", profile.getBirthDate());
            response.put("gender", profile.getGender());
        }
        
        return response;
    }
    
    public boolean hasRole(Long userId, String roleCode) {
        return userRoleDAO.hasRole(userId, roleCode);
    }
    
    public boolean isAdmin(Long userId) {
        return hasRole(userId, Constants.ROLE_ADMIN);
    }
    
    public void validateUserAccess(Long userId) {
        User user = userDAO.findUserById(userId);
        if (user == null) {
            throw new IllegalArgumentException("User not found");
        }
        if (!Constants.USER_STATUS_ACTIVE.equals(user.getStatus())) {
            throw new IllegalArgumentException("User account is not active");
        }
    }
}
