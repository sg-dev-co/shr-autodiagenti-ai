package sg.sample.mapper;

import org.apache.ibatis.annotations.Mapper;
import sg.sample.model.UserRole;

import java.util.List;

/**
 * 사용자 권한 데이터베이스 매퍼 인터페이스
 * MyBatis를 사용하여 사용자 권한 관련 SQL 쿼리를 처리합니다.
 * 
 * @author Sample Project
 * @version 1.0.0
 * @since 2024
 */
@Mapper
public interface UserRoleMapper {
    
    /**
     * 사용자 권한 생성
     * 
     * @param userRole 생성할 권한 정보
     * @return 생성된 행 수
     */
    int insertUserRole(UserRole userRole);
    
    /**
     * ID로 권한 조회
     * 
     * @param id 조회할 권한 ID
     * @return 권한 정보 (없으면 null)
     */
    UserRole selectUserRoleById(Long id);
    
    /**
     * 사용자 ID로 권한 목록 조회
     * 
     * @param userId 조회할 사용자 ID
     * @return 권한 목록
     */
    List<UserRole> selectUserRolesByUserId(Long userId);
    
    /**
     * 사용자 ID와 권한 코드로 권한 조회
     * 
     * @param userId 조회할 사용자 ID
     * @param roleCode 조회할 권한 코드
     * @return 권한 정보 (없으면 null)
     */
    UserRole selectUserRoleByUserIdAndRoleCode(Long userId, String roleCode);
    
    /**
     * 전체 권한 목록 조회
     * 
     * @return 전체 권한 목록
     */
    List<UserRole> selectAllUserRoles();
    
    /**
     * 권한 정보 수정
     * 
     * @param userRole 수정할 권한 정보
     * @return 수정된 행 수
     */
    int updateUserRole(UserRole userRole);
    
    /**
     * 권한 삭제
     * 
     * @param id 삭제할 권한 ID
     * @return 삭제된 행 수
     */
    int deleteUserRole(Long id);
    
    /**
     * 사용자 ID로 권한 삭제
     * 
     * @param userId 삭제할 사용자 ID
     * @return 삭제된 행 수
     */
    int deleteUserRolesByUserId(Long userId);
}
